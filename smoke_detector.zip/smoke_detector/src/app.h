/*
 * Copyright (C) 2017 C-SKY Microsystems Co., All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __IOT_H_
#define __IOT_H_
#include <udata.h>
#include <yoc/iot.h>

#define DATA_TYPE_BATTERY_VALUE  0
#define DATA_TYPE_BATTERY_ALARM  1
#define DATA_TYPE_SENSOR_VALUE   2
#define DATA_TYPE_SENSOR_ALARM   3

#define EVENT_DATA_REPORT     (EVENT_USER + 0x0501)
#define EVENT_BUTTON_REPORT   (EVENT_USER + 0x0502)
#define EVENT_BATTRY_CHECK    (EVENT_USER + 0x0503)
#define EVENT_SENSOR_CHECK    (EVENT_USER + 0x0504)
#define EVENT_CHANNEL_CHECK   (EVENT_USER + 0x0505)
#define EVENT_CHANNEL_CLOSE   (EVENT_USER + 0x0506)
#define EVENT_FOTA_START_RUN  (EVENT_USER + 0x0507)

typedef struct g_app_context {
    iot_t *iot_handle;
    iot_channel_t *iot_ch;
} g_app_context_t;


iot_t *channel_new(int left_time);
int channel_open(void *argv);
void channel_close(void *argv);
void data_set(iot_channel_t *iot_ch, uint8_t type, int value);
void data_set_device_name(iot_channel_t *iot_ch);

/* exception */
void app_exception_init(void);
void app_exception_event(uint32_t event_id);

#endif