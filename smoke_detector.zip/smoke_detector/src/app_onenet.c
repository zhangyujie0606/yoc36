/*
 * Copyright (C) 2017 C-SKY Microsystems Co., All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <yoc_config.h>

#ifdef CONFIG_CLOUDIO_ONENET
#include <aos/log.h>
#include <aos/debug.h>
#include "app.h"
#include <aos/kv.h>

static const char* TAG =  "app";

#define  COP_ACTIVE_URL_OPEN    "open.c-sky.com"
#define  COP_ACTIVE_URL_CID     "cid.c-sky.com"

static void channel_set(uData *udata, void *arg)
{
    uData *node;
    slist_for_each_entry(&udata->head, node, uData, head) {
        if (node->value.updated) {
            if (node->value.type == TYPE_STR) {
                LOGI(TAG, "ch set (%s,%s)", node->key.v_str, node->value.v_str);
            } else if (node->value.type == TYPE_FLOAT){
                LOGI(TAG, "ch set (%s,%d)", node->key.v_str, (int)node->value.v_float);
            } else {
                LOGI(TAG, "ch set (%s,%d)", node->key.v_str, (int)node->value.v_int);
            }
        }
    }

    node = yoc_udata_get(udata, value_s("5/0/2"));

    if (node->value.updated) {
        //aos_schedule_call(fota_check_action, NULL);
    }
}

static void channel_get(uData *udata, void *arg)
{
    yoc_udata_set(udata, value_s("3300/0/5700"), value_f(10), 1);
    //yoc_udata_set(udata, value_s("3303/0/5701"), value_s("degree"), 1);

    //yoc_udata_set(udata, value_s("3311/0/5850"), value_b(rand() % 2), 1);
    //yoc_udata_set(udata, value_s("3311/0/5851"), value_i(rand() % 80), 1);
}

static void init_channel_udata(uData *udata)
{
    /* battery Voltage */
    yoc_udata_set(udata, value_s("3316/0/5700"), value_f(0), 0);
    yoc_udata_set(udata, value_s("3316/0/5701"), value_s("mV"), 0);
    yoc_udata_set(udata, value_s("3316/0/5601"), value_f(0), 0);

    /* sensor */
    yoc_udata_set(udata, value_s("3300/0/5700"), value_f(0), 0);
    yoc_udata_set(udata, value_s("3300/0/5701"), value_s("unit"), 0);
    yoc_udata_set(udata, value_s("3300/0/5601"), value_f(0), 0);
    yoc_udata_set(udata, value_s("3300/0/5605"), value_b(0), 0);

    /* fota */
    yoc_udata_set(udata, value_s("5/0/2"), value_b(0), 0);
}

void channel_close(void *argv)
{
    g_app_context_t *ctx = (g_app_context_t *)argv;
    if (ctx) {
        iot_channel_close(ctx->iot_ch);
        ctx->iot_ch = NULL;
    }
}

int channel_open(void *argv)
{
    int ret, intvalue = 0;

    /* COP reg */
    aos_kv_getint("onenet_reg", &intvalue);
    LOGI(TAG, "onenet flag :%x", intvalue);
    if (intvalue != 1)
    {
        extern int cop_register(const char *url);
        ret = cop_register(COP_ACTIVE_URL_CID);
        if (ret == 0) {
            aos_kv_setint("onenet_reg", 1);
        } else {
            LOGE(TAG, "onenet reg: %x", ret);
        }
    }

    /* open channel */
    g_app_context_t *ctx = (g_app_context_t *)argv;

    iot_channel_t *iot_ch = iot_channel_open(ctx->iot_handle, NULL);

    if (iot_ch == NULL) {
        LOGE(TAG, "iot ch open");
        return -1;
    }

    iot_channel_config(iot_ch, channel_set, channel_get, NULL);

    /* init data node */
    init_channel_udata(iot_ch->uData);

    ctx->iot_ch = iot_ch;

    iot_channel_start(iot_ch);

    return 0;
}

iot_t *channel_new(int left_time)
{
    iot_onenet_config_t cfg = {.lifetime = left_time};
    return iot_new_onenet(&cfg);
}

void data_set(iot_channel_t *iot_ch, uint8_t type, int val)
{
    switch (type) {
        case DATA_TYPE_BATTERY_VALUE:
            yoc_udata_set(iot_ch->uData, value_s("3316/0/5700"), value_f(val), 1);
            break;
        case DATA_TYPE_BATTERY_ALARM:
            yoc_udata_set(iot_ch->uData, value_s("3316/0/5601"), value_f(val), 1);
            break;
        case DATA_TYPE_SENSOR_VALUE:
            yoc_udata_set(iot_ch->uData, value_s("3300/0/5700"), value_f(val), 1);
            break;
        case DATA_TYPE_SENSOR_ALARM:
            yoc_udata_set(iot_ch->uData, value_s("3300/0/5601"), value_f(val), 1);
            break;
    }
}

void data_set_device_name(iot_channel_t *iot_ch)
{
    return;
}
#endif