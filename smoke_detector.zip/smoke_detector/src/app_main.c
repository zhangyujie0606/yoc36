/*
 * Copyright (C) 2017 C-SKY Microsystems Co., All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <yoc_config.h>

#include <stdlib.h>
#include <aos/log.h>
#include <aos/debug.h>
#include <aos/kv.h>
#include <aos/kernel.h>
#include <yoc/uservice.h>
#include <yoc/netmgr.h>

#include <drv_gpio.h>
#include <pin_name.h>
#include <pin.h>

#include <devices/led.h>
#include <devices/sensor.h>
#include <devices/battery.h>
#include <devices/devicelist.h>

#include <yoc/fota.h>
#include <yoc/netio.h>

#include "app_init.h"
#include "app.h"

#if defined(CONFIG_CLOUDIO_ALIMQTT)
static const char *TAG =  "AppMQTT";
#elif defined(CONFIG_CLOUDIO_ALICOAP)
static const char *TAG =  "AppCoAP";
#elif defined(CONFIG_CLOUDIO_ONENET)
static const char *TAG =  "AppOneNET";
#elif defined(CONFIG_CLOUDIO_OCEANCON)
static const char *TAG =  "AppOCEA";
#else
static const char *TAG =  "";
#error "unkonwn cloudio define"
#endif


#define LED_STATUS_NET_DOWN 0
#define LED_STATUS_NET_UP   1

#define DEVICE_LED_NAME     "ledrgb"
#define DEVICE_BATTERY_NAME "battery_simulate"
#define DEVICE_SENSOR_NAME  "simulate"

#define KV_FOTA_CYCLE_MS        "fota_cycle"
#define KV_FOTA_START_MS        "fota_start"
#define FOTA_CYCLE_DELAY_TIME   (60000)
#define FOTA_START_DELAY_TIME   (0)

#define MIN_RESTRITION  0x1
#define MAX_RESTRITION  0x2

#define START_DELAY_TIME      1000 /* ms */

#define LED_ON_PERIOD        0
#define LED_OFF_PERIOD       1
#define DATA_REPORT_PERIOD   2
#define SENSOR_CHECK_PERIOD  3
#define BATTERY_CHECK_PERIOD 4
#define BATTERY_THRESHOLD    5
#define SENSOR_THRESHOLD     6
#define LIFT_TIME            7

typedef struct kv_int {
    char *key;
    int def_value;
    int value;
    uint8_t restriction;
    int min_value;
    int max_value;
} kv_int_t;

static kv_int_t g_config[] = {
    {"led_on_period",  200, 0, MIN_RESTRITION, 0},
    {"led_off_period", 500, 0, MIN_RESTRITION, 0},
    {"data_report_period", 5000, 0, MIN_RESTRITION, 0},
    {"sensor_check_period", 7000, 0, MIN_RESTRITION, 0},
    {"battery_check_period", 11000, 0, MIN_RESTRITION, 0},
    {"battery_threshold", 2000, 0, MIN_RESTRITION, 0},
    {"sensor_threshold", 270, MIN_RESTRITION, 0},
    {"life_time", 900, 0, MIN_RESTRITION | MAX_RESTRITION, 60, 24 * 60 * 60},
};

static int battery_event(hal_battery_event_t event);
static g_app_context_t g_app_ctx = {0};
#if defined CONSOLE_ID && (CONSOLE_ID == 2)
static led_pin_config_t led_config = {PA2, LED_PIN_NOT_SET, LED_PIN_NOT_SET, 1};
#else
static led_pin_config_t led_config = {EXAMPLE_LED_R_PIN, EXAMPLE_LED_G_PIN, EXAMPLE_LED_B_PIN, 1};
#endif
static battery_pin_config_t battery_config = {EXAMPLE_BATTERY_PIN, battery_event};
static gpio_pin_handle_t button_dev;
#ifdef CONFIG_FOTA
static int g_fota_delay_timer = 0;
static fota_t *g_fota_handle = NULL;
#endif
static int g_event_time_inited = 0;
static int g_iot_connected = 0;
static void user_local_event_cb(uint32_t event_id, const void *param, void *context);

static void buzzer_on()
{
    LOGW(TAG, "Buzzer On!");
}

static void led_set_status(int status)
{
    static dev_t *led_dev = NULL;

    if (led_dev == NULL) {
        led_dev = led_open_id(DEVICE_LED_NAME, 1);
    }

    if (led_dev == NULL) {
        LOGE(TAG, "led_dev open err!");
        return;
    }

    if (status == LED_STATUS_NET_DOWN) {
        led_control(led_dev, COLOR_GENERIC, 100, 1000);
    } else if (status == LED_STATUS_NET_UP) {
        led_control(led_dev, COLOR_GENERIC, g_config[LED_ON_PERIOD].value, g_config[LED_OFF_PERIOD].value);
    }

    /* LED lights are working all the time,no need to close.*/
    //led_close(led_dev);
}

static void data_report_action(void)
{
    int ret;
    iot_channel_t *ch = g_app_ctx.iot_ch;

    sensor_simulate_t sval;
    dev_t *sensor_dev;

    if (ch != NULL && g_iot_connected) {
        sensor_dev = sensor_open_id(DEVICE_SENSOR_NAME, 0);
        ret = sensor_fetch(sensor_dev);

        if (sensor_getvalue(sensor_dev, (void *)&sval, sizeof(sensor_simulate_t)) == 0) {
            LOGI(TAG, "report read sensor: %d ret: %d", sval.degree, ret);

            if (sval.degree >= g_config[SENSOR_THRESHOLD].value) {
                buzzer_on();
                data_set(ch, DATA_TYPE_SENSOR_ALARM, 1);
            } else {
                data_set(ch, DATA_TYPE_SENSOR_ALARM, 0);
            }

            data_set(ch, DATA_TYPE_SENSOR_VALUE, sval.degree);
            data_set_device_name(ch);
            iot_channel_push(ch, 0);
        } else {
            LOGE(TAG, "read sensor");
        }

        sensor_close(sensor_dev);
    } else {
        //LOGW(TAG, "channel closed");
    }
    event_publish_delay(EVENT_DATA_REPORT, NULL, g_config[DATA_REPORT_PERIOD].value);
}

static void sensor_check_action(void)
{
    int ret;
    iot_channel_t *ch = g_app_ctx.iot_ch;

    sensor_simulate_t sval;
    dev_t *sensor_dev;

    if (ch != NULL && g_iot_connected) {
        sensor_dev = sensor_open_id(DEVICE_SENSOR_NAME, 0);
        ret = sensor_fetch(sensor_dev);

        if (sensor_getvalue(sensor_dev, (void *)&sval, sizeof(sensor_simulate_t)) == 0) {
            LOGI(TAG, "read sensor check: %d, ret: %d", sval.degree, ret);

            if (sval.degree >= g_config[SENSOR_THRESHOLD].value) {
                buzzer_on();
                data_set(ch, DATA_TYPE_SENSOR_VALUE, sval.degree);
                data_set(ch, DATA_TYPE_SENSOR_ALARM, 1);
                data_set_device_name(ch);
                iot_channel_push(ch, 0);
            }

        } else {
            LOGE(TAG, "read sensor");
        }

        sensor_close(sensor_dev);
    } else {
        //LOGW(TAG, "channel closed");
    }
    event_publish_delay(EVENT_SENSOR_CHECK, NULL, g_config[SENSOR_CHECK_PERIOD].value);
}

static void battery_check_action()
{
    int ret;
    iot_channel_t *ch = g_app_ctx.iot_ch;
    dev_t *dev;
    battery_voltage_t battery_val;

    if (ch != NULL && g_iot_connected) {
        dev = battery_open_id(DEVICE_BATTERY_NAME, 1);

        ret = battery_fetch(dev, VOLTAGE);

        if (ret == 0) {
            ret = battery_getvalue(dev, VOLTAGE, &battery_val, sizeof(battery_voltage_t));

            if (ret == 0) {
                LOGI(TAG, "read battery: %d mv", battery_val.volt);

                if (battery_val.volt <= g_config[BATTERY_THRESHOLD].value) {
                    data_set(ch, DATA_TYPE_BATTERY_ALARM, 1);
                } else {
                    data_set(ch, DATA_TYPE_BATTERY_ALARM, 0);
                }

                data_set(ch, DATA_TYPE_BATTERY_VALUE, battery_val.volt);
                data_set_device_name(ch);
                iot_channel_push(ch, 0);
            } else {
                LOGE(TAG, "battery get value");
            }
        } else {
            LOGE(TAG, "battery fetch");
        }

        battery_close(dev);
    } else {
        //LOGW(TAG, "channel closed");
    }
    event_publish_delay(EVENT_BATTRY_CHECK, NULL, g_config[BATTERY_CHECK_PERIOD].value);
}

void button_push_action(void)
{
    iot_channel_t *ch = g_app_ctx.iot_ch;

    if (ch != NULL && g_iot_connected) {
        data_set_device_name(ch);
        iot_channel_push(ch, 1);
    }
}

static void iot_event(uint32_t event_id, const void *param, void *context)
{
    if (g_app_ctx.iot_ch == NULL) {
        //LOGW(TAG, "channel closed");
        return;
    }

    switch (event_id) {
        case EVENT_IOT_CONNECT_SUCCESS:
            LOGD(TAG, "CONNNECT SUCCESS");
            g_iot_connected = 1;

            /* start first data push */
            if (g_event_time_inited == 0) {
                event_publish_delay(EVENT_DATA_REPORT, NULL, START_DELAY_TIME);
                event_publish_delay(EVENT_BATTRY_CHECK, NULL, START_DELAY_TIME + 100);
                event_publish_delay(EVENT_SENSOR_CHECK, NULL, START_DELAY_TIME + 200);
                g_event_time_inited = 1;
            }

            break;

        case EVENT_IOT_CONNECT_FAILED:
        case EVENT_IOT_DISCONNECTED:
            g_iot_connected = 0;
            channel_close(&g_app_ctx);
            break;
        case EVENT_IOT_PUSH_SUCCESS:
            LOGD(TAG, "PUSH_SUCCESS");
            break;

        case EVENT_IOT_PUSH_FAILED:
            break;

        default:
            aos_check_param(NULL);
    };

    /*do exception process */
    app_exception_event(event_id);

}

static void network_event(uint32_t event_id, const void *param, void *context)
{
    switch(event_id) {
    case EVENT_NETMGR_GOT_IP:
        LOGD(TAG, "EVENT_NETMGR_GOT_IP");
        led_set_status(LED_STATUS_NET_UP);
        channel_open(&g_app_ctx);
#ifdef CONFIG_FOTA
        event_publish_delay(EVENT_FOTA_START_RUN, NULL, g_fota_delay_timer);
#endif
        break;
    case EVENT_NETMGR_NET_DISCON:
        led_set_status(LED_STATUS_NET_DOWN);

        channel_close(&g_app_ctx);
        break;
    }

    /*do exception process */
    app_exception_event(event_id);
}

static void user_local_event_cb(uint32_t event_id, const void *param, void *context)
{
    if (event_id == EVENT_DATA_REPORT) {
        data_report_action();
    } else if (event_id == EVENT_BUTTON_REPORT) {
        button_push_action();
    } else if (event_id == EVENT_BATTRY_CHECK) {
        battery_check_action();
    } else if (event_id == EVENT_SENSOR_CHECK) {
        sensor_check_action();
    } else if (event_id == EVENT_CHANNEL_CHECK) {
        int res = -1;
        if (netmgr_is_gotip(app_netmgr_hdl)) {
            res = channel_open(&g_app_ctx);
        } else {
            LOGW(TAG, "net not ready");
        }

        /* error before do connnect, trans to EVENT_IOT_CONNECT_FAILED to retry */
        if (res != 0) {
            event_id = EVENT_IOT_CONNECT_FAILED;
        }

    } else if (event_id == EVENT_CHANNEL_CLOSE) {
        channel_close(&g_app_ctx);
    } else if (event_id == EVENT_OS_REBOOT) {
        aos_reboot();
#ifdef CONFIG_FOTA
    } else if (event_id == EVENT_FOTA_START_RUN) {
        fota_start(g_fota_handle);
#endif
    }

    /*do exception process */
    app_exception_event(event_id);
}

static void load_config(kv_int_t *config)
{
    int i, ret;
    for (i = 0; i < sizeof(g_config) / sizeof(kv_int_t); i++) {
        ret = aos_kv_getint(g_config[i].key, &g_config[i].value);
        if (ret < 0) {
            g_config[i].value = g_config[i].def_value;
        } else {
            if ((g_config[i].restriction & MIN_RESTRITION) && g_config[i].value <= g_config[i].min_value) {
                g_config[i].value = g_config[i].min_value;
                LOGW(TAG, "Min Param: %s=%d", g_config[i].key, g_config[i].value);
            } else if ((g_config[i].restriction & MAX_RESTRITION) && g_config[i].value >= g_config[i].max_value) {
                g_config[i].value = g_config[i].max_value;
                LOGW(TAG, "Max Param: %s=%d", g_config[i].key, g_config[i].value);
            } else {
                LOGW(TAG, "Param: %s=%d", g_config[i].key, g_config[i].value);
            }
        }
    }
}

/* calling from irq, we should not do malloc or delay here */
int battery_event(hal_battery_event_t event)
{
    return 0;
}

/* calling from irq, we should not do malloc or delay here */
static void notify_button_callback(int idx)
{
    event_publish(EVENT_BUTTON_REPORT, NULL);
}

#ifdef CONFIG_FOTA
#ifndef CONFIG_CLOUDIO_OCEANCON
static int fota_event_cb(void *arg, fota_event_e event) //return 0: still do the default handle      not zero: only do the user handle
{
    fota_t *fota = (fota_t *)arg;
    switch (event) {
        case FOTA_EVENT_VERSION:
            LOGD(TAG, "FOTA VERSION :%x", fota->status);
            break;

        case FOTA_EVENT_START:
            LOGD(TAG, "FOTA START :%x", fota->status);
            break;

        case FOTA_EVENT_FAIL:
            LOGD(TAG, "FOTA FAIL :%x", fota->status);
            break;

        case FOTA_EVENT_FINISH:
            LOGD(TAG, "FOTA FINISH :%x", fota->status);
            break;

        default:
            break;
    }
    return 0;
}
#endif
#endif

void app_main()
{
    int ret;

    board_yoc_init();

    app_exception_init();

    /* Init user sensor drivers */
    sensor_simulate_register(NULL, 0);
    battery_simulate_register(&battery_config, 1);
    /* Init a gpio for button, if you press the button it will send data to server for test */
    button_dev =  csi_gpio_pin_initialize(EXAMPLE_PUSH_BUTTON_PIN, notify_button_callback);
    csi_gpio_pin_config_direction(button_dev, GPIO_DIRECTION_INPUT);
    csi_gpio_pin_set_irq(button_dev, GPIO_IRQ_MODE_RISING_EDGE, 1);

    /* Init the led for system status notify */
    led_rgb_register(&led_config, 1);
    led_set_status(LED_STATUS_NET_DOWN);

    /* Subscribe Netmgr Event */
    event_subscribe(EVENT_NETMGR_GOT_IP, network_event, NULL);
    event_subscribe(EVENT_NETMGR_NET_DISCON, network_event, NULL);

    /* Subscribe IOT Event */
    event_subscribe(EVENT_IOT_CONNECT_SUCCESS, iot_event, NULL);
    event_subscribe(EVENT_IOT_CONNECT_FAILED, iot_event, NULL);
    event_subscribe(EVENT_IOT_DISCONNECTED, iot_event, NULL);
    event_subscribe(EVENT_IOT_PUSH_SUCCESS, iot_event, NULL);
    event_subscribe(EVENT_IOT_PUSH_FAILED, iot_event, NULL);

    /* App check timer */
    event_subscribe(EVENT_DATA_REPORT, user_local_event_cb, NULL);
    event_subscribe(EVENT_BATTRY_CHECK, user_local_event_cb, NULL);
    event_subscribe(EVENT_SENSOR_CHECK, user_local_event_cb, NULL);
    event_subscribe(EVENT_BUTTON_REPORT, user_local_event_cb, NULL);

    event_subscribe(EVENT_CHANNEL_CHECK, user_local_event_cb, NULL);
    event_subscribe(EVENT_CHANNEL_CLOSE, user_local_event_cb, NULL);

    /* Subscribe reboot Event */
    event_subscribe(EVENT_OS_REBOOT, user_local_event_cb, NULL);

    /* load config */
    load_config(g_config);

    g_app_ctx.iot_handle = channel_new(g_config[LIFT_TIME].value);

#ifdef CONFIG_FOTA
#ifdef CONFIG_CLOUDIO_OCEANCON // lwm2m
    fota_register_coap();
    netio_register_coap();
    netio_register_flash();
    g_fota_handle = fota_open("coap", "flash://misc", NULL);
    // fota = fota_open("cop", "flash://misc", fota_event_cb);
#else // cop
    fota_register_cop();
    netio_register_http();
    netio_register_flash();
    // fota = fota_open("cop", "flash://misc", NULL);
    g_fota_handle = fota_open("cop", "flash://misc", fota_event_cb);
#endif

    ret = aos_kv_getint(KV_FOTA_CYCLE_MS, &(g_fota_handle->sleep_time));
    if (ret != 0 || g_fota_handle->sleep_time < 1000) {
        g_fota_handle->sleep_time = FOTA_CYCLE_DELAY_TIME;
    }
    g_fota_handle->timeoutms = 10000;
    g_fota_handle->retry_count = 3;

    ret = aos_kv_getint(KV_FOTA_START_MS, &g_fota_delay_timer);
    if (ret != 0) {
        g_fota_delay_timer = FOTA_START_DELAY_TIME;
    }

    event_subscribe(EVENT_FOTA_START_RUN, user_local_event_cb, NULL);
#endif
}

