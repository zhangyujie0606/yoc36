/*
 * Copyright (C) 2017 C-SKY Microsystems Co., All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <yoc_config.h>
#ifdef CONFIG_CLOUDIO_OCEANCON
#include <yoc/sysinfo.h>
#include <aos/log.h>
#include <aos/debug.h>
#include "app.h"
#include <aos/kv.h>

static const char* TAG =  "app";

#define  COP_ACTIVE_URL_OPEN    "open.c-sky.com"
#define  COP_ACTIVE_URL_CID     "cid.c-sky.com"

#define MESSAGE_ID_SMOKE    (0x0)
#define MESSAGE_ID_BATTERY  (0x1)

#define MESSAGE_SMOKE_TAG    (0x01)
#define MESSAGE_BATTERY_TAG  (0x02)

static uint8_t message_smoke_count;
static uint8_t message_battery_count;
static uint8_t message_type;

static void channel_set(uData *udata, void *arg)
{
    uData *d;
    d = yoc_udata_get(udata, value_s("reset"));

    if (d->value.updated) {
        if (d->value.v_int == 0) {
            LOGI(TAG, "reset OFF");
        } else if (d->value.v_int == 1) {
            LOGI(TAG, "reset ON");
        } else {
            LOGI(TAG, "reset Wrong");
        }
    }

    d = yoc_udata_get(udata, value_s("FOTA"));

    if (d->value.updated && d->value.v_int == 1) {
        LOGI(TAG, "FOTA START");
        //aos_schedule_call(fota_check_action, NULL);
    }
}

static void channel_get(uData *udata, void *arg)
{
    message_type |= MESSAGE_SMOKE_TAG;
    message_smoke_count++;
    yoc_udata_set(udata, value_s("smoke"), value_i(10), 0);
    yoc_udata_set(udata, value_s("smokeAlarm"), value_i(0), 0);
}

static void _swap_buf(uint8_t *buf, uint32_t len)
{
    char tmp, i;

    for (i = 0; i < len / 2; i ++) {
        tmp = *(buf + i);
        *(buf + i) = *(buf + len - i - 1);
        *(buf + len - i - 1) = tmp;
    }
}

int udata_to_buffer(uData *data, void *buffer)
{
    uData *d;
    int val;
    if (message_type & MESSAGE_BATTERY_TAG) {

        *(uint8_t*)buffer = MESSAGE_ID_BATTERY;

        d = yoc_udata_get(data, value_s("batteryLevel"));

        memcpy((uint8_t*)buffer + 1, (uint8_t*)&(d->value.v_int), 1);

        d = yoc_udata_get(data, value_s("batteryVoltage"));
        val = d->value.v_int;

        /* convert addr to big endian */
        _swap_buf((uint8_t*)&(val), sizeof(val));

        memcpy((uint8_t*)buffer + 2, &(val), 4);

        message_battery_count--;
        if (0 == message_battery_count) {
            message_type &= ~MESSAGE_BATTERY_TAG;
        }

        return 6;
    } else if(message_type & MESSAGE_SMOKE_TAG) {

        *(uint8_t*)buffer = MESSAGE_ID_SMOKE;

        d = yoc_udata_get(data, value_s("smokeAlarm"));

        memcpy((uint8_t*)buffer + 1, &(d->value.v_int), 1);

        d = yoc_udata_get(data, value_s("smoke"));
        val = d->value.v_int;

        /* convert addr to big endian */
        _swap_buf((uint8_t*)&(val), sizeof(val));

        memcpy((uint8_t*)buffer + 2, &(val), 4);

        message_smoke_count--;
        if (0 == message_smoke_count) {
            message_type &= ~MESSAGE_SMOKE_TAG;
        }

        return 6;
    } 
    return 0;
}

int buffer_to_udata(uData *data, void *buffer, int len)
{
    if (len != 2) {
        return -1;
    }

    if (*(uint8_t*)buffer == 3) {
        yoc_udata_set(data, value_s("reset"), value_i(*((uint8_t*)buffer + 1)), 1);
    } else if (*(uint8_t*)buffer == 2) {
        yoc_udata_set(data, value_s("FOTA"), value_i(*((uint8_t*)buffer + 1)), 1);
    }

    return 0;
}

void channel_close(void *argv)
{
    g_app_context_t *ctx = (g_app_context_t *)argv;
    if (ctx) {
        iot_channel_close(ctx->iot_ch);
        ctx->iot_ch = NULL;
    }
}

static void init_message_info(void)
{
    message_smoke_count = 1;
    message_battery_count = 0;
    message_type = 0;
}

int channel_open(void *argv)
{
    int ret, intvalue = 0;

    /* COP reg */
    aos_kv_getint("oceancon_reg", &intvalue);
    LOGI(TAG, "oceancon flag :%x", intvalue);
    if (intvalue != 1)
    {
        extern int cop_register(const char *url);
        ret = cop_register(COP_ACTIVE_URL_CID);
        if (ret == 0) {
            aos_kv_setint("oceancon_reg", 1);
        } else {
            LOGE(TAG, "oceancon reg: %x", ret);
        }
    }

    /* open channel */
    g_app_context_t *ctx = (g_app_context_t *)argv;

    iot_channel_t *iot_ch = iot_channel_open(ctx->iot_handle, NULL); /*update, publish topic*/

    if (iot_ch == NULL) {
        LOGE(TAG, "iot ch open");
        return -1;
    }

    iot_channel_config(iot_ch, channel_set, channel_get, NULL);

    /* init data node */
    yoc_udata_set(iot_ch->uData, value_s("batteryVoltage"), value_i(0), 0);
    yoc_udata_set(iot_ch->uData, value_s("batteryLevel"), value_i(0), 0);
    yoc_udata_set(iot_ch->uData, value_s("smoke"), value_i(0), 0);
    yoc_udata_set(iot_ch->uData, value_s("smokeAlarm"), value_i(0), 0);
    yoc_udata_set(iot_ch->uData, value_s("reset"), value_i(0), 0);
    yoc_udata_set(iot_ch->uData, value_s("FOTA"), value_i(0), 0);

    ctx->iot_ch = iot_ch;

    /* init message info*/
    init_message_info();

    iot_channel_start(iot_ch);

    return 0;
}

iot_t *channel_new(int left_time)
{
    iot_oceancon_config_t config = {
        "coap://180.101.147.115:5683",
        left_time,
        udata_to_buffer,
        buffer_to_udata,
        50
    };

    //strncpy(config.endpoint, aos_get_imei(), 19);

    return iot_new_oceancon(&config);
}

void data_set(iot_channel_t *iot_ch, uint8_t type, int val)
{
    aos_check_param(iot_ch);

    switch (type) {
        case DATA_TYPE_BATTERY_VALUE:
            message_type |= MESSAGE_BATTERY_TAG;
            message_battery_count++;
            yoc_udata_set(iot_ch->uData, value_s("batteryVoltage"), value_i(val), 1);
            break;
        case DATA_TYPE_BATTERY_ALARM:
            yoc_udata_set(iot_ch->uData, value_s("batteryLevel"), value_i(val), 1);
            break;
        case DATA_TYPE_SENSOR_VALUE:
            message_type |= MESSAGE_SMOKE_TAG;
            message_smoke_count++;
            yoc_udata_set(iot_ch->uData, value_s("smoke"), value_i(val), 1);
            break;
        case DATA_TYPE_SENSOR_ALARM:
            yoc_udata_set(iot_ch->uData, value_s("smokeAlarm"), value_i(val), 1);
            break;
    }
}

void data_set_device_name(iot_channel_t *iot_ch)
{
    return;
}

#endif
