/*
 * Copyright (C) 2017 C-SKY Microsystems Co., All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <yoc_config.h>

#ifdef CONFIG_CLOUDIO_ALIMQTT
#include <aos/log.h>
#include <aos/debug.h>
#include "app.h"
#include <yoc/sysinfo.h>
static const char *TAG = "app";
static void channel_set(uData *udata, void *arg)
{
    uData *node;
    slist_for_each_entry(&udata->head, node, uData, head)
    {
        if (node->value.updated)
        {
            if (node->value.type == TYPE_STR)
            {
                LOGI(TAG, "ch set (%s,%s)", node->key.v_str, node->value.v_str);
            }
            else
            {
                LOGI(TAG, "ch set (%s,%d)", node->key.v_str, node->value.v_int);
            }
        }
    }
}

static void channel_get(uData *udata, void *arg)
{
    yoc_udata_set(udata, value_s("smoke"), value_i(10), 1);
    //yoc_udata_set(udata, value_s("smokeAlarm"), value_i(0), 1);
}

static void init_channel_udata(uData *udata)
{
    /* init data node */
    yoc_udata_set(udata, value_s("batteryVoltage"), value_i(0), 0);
    yoc_udata_set(udata, value_s("batteryLevel"), value_i(0), 0);
    yoc_udata_set(udata, value_s("smoke"), value_i(0), 0);
    yoc_udata_set(udata, value_s("smokeAlarm"), value_i(0), 0);
    yoc_udata_set(udata, value_s("reset"), value_i(0), 0);
    yoc_udata_set(udata, value_s("deviceName"), value_s(aos_get_device_name()), 1);
}

void channel_close(void *argv)
{
    g_app_context_t *ctx = (g_app_context_t *)argv;
    if (ctx) {
        iot_channel_close(ctx->iot_ch);
        ctx->iot_ch = NULL;
    }
}

int channel_open(void *argv)
{
    g_app_context_t *ctx = (g_app_context_t *)argv;

    iot_channel_t *iot_ch = iot_channel_open(ctx->iot_handle, "thing/event/property/post,thing/service/property/set");

    if (iot_ch == NULL) {
        LOGE(TAG, "iot ch open");
        return -1;
    }

    iot_channel_config(iot_ch, channel_set, channel_get, NULL);

    /* init data node */
    init_channel_udata(iot_ch->uData);

    ctx->iot_ch = iot_ch;

    iot_channel_start(iot_ch);

    return 0;
}

iot_t *channel_new(int left_time)
{
    iot_alimqtt_config_t cfg = {.server_url_suffix =
                                    "iot-as-mqtt.cn-shanghai.aliyuncs.com:1883"};

    return iot_new_alimqtt(&cfg);
}

void data_set(iot_channel_t *iot_ch, uint8_t type, int val)
{
    switch (type)
    {
    case DATA_TYPE_BATTERY_VALUE:
        yoc_udata_set(iot_ch->uData, value_s("batteryVoltage"), value_i(val), 1);
        break;
    case DATA_TYPE_BATTERY_ALARM:
        yoc_udata_set(iot_ch->uData, value_s("batteryLevel"), value_i(val), 1);
        break;
    case DATA_TYPE_SENSOR_VALUE:
        yoc_udata_set(iot_ch->uData, value_s("smoke"), value_i(val), 1);
        break;
    case DATA_TYPE_SENSOR_ALARM:
        yoc_udata_set(iot_ch->uData, value_s("smokeAlarm"), value_i(val), 1);
        break;
    }
}

void data_set_device_name(iot_channel_t *iot_ch)
{
    yoc_udata_set(iot_ch->uData, value_s("deviceName"), value_s(aos_get_device_name()), 1);
}
#endif
