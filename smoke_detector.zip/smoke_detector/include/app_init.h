#ifndef __INIT__H__
#define __INIT__H__
#include <yoc/netmgr.h>
#include <yoc/netmgr.h>

extern netmgr_hdl_t app_netmgr_hdl;
void board_cli_init(utask_t *task);
void board_yoc_init(void);

#endif